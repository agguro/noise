Authors: 
 * Jason Bevins <jlbezigvins@gmzigail.com> (for great email, take off every 'zig'.)

contributor:
 * Joachim Schiele <js@lastlog.de>, wrote the cmake system
